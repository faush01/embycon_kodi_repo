import sys
import xbmcaddon
import xbmcgui
import xbmc

Addon = xbmcaddon.Addon('screensaver.embycon')

__scriptname__ = Addon.getAddonInfo('name')
__path__ = Addon.getAddonInfo('path')


class Screensaver(xbmcgui.WindowXMLDialog):
    class ExitMonitor(xbmc.Monitor):

        def __init__(self, exit_callback):
            self.exit_callback = exit_callback

        def onScreensaverDeactivated(self):
            xbmc.log('EmbyCon.Screensaver: sending exit_callback')
            self.exit_callback()

    def onInit(self):
        xbmc.log('EmbyCon.Screensaver: onInit')
        self.monitor = self.ExitMonitor(self.exit)

    def exit(self):
        xbmc.log('EmbyCon.Screensaver: Exit requested')

        #xbmc.executebuiltin("RunScript(plugin.video.embycon,0,?mode=CHANGE_USER)")

        settings = xbmcaddon.Addon()
        wait_on_select = settings.getSetting('wait_for_user_dialog') == 'true'
        if not wait_on_select:
            xbmc.log("EmbyCon.Screensaver not waiting for user dialog")
            self.close()
            return

        screen_saver_image = self.getControl(3000)
        screen_saver_image.setVisible(False)
        screen_saver_label = self.getControl(3001)

        loops = 20
        while wait_on_select and not xbmc.getCondVisibility("Window.IsVisible(selectdialog)") and loops > 0:
            loops = loops - 1
            xbmc.log("EmbyCon.Screensaver, waiting 500 ms for selectdialog : " + str(loops))
            screen_saver_label.setLabel("Waiting for user dialog (" + str(loops) + ")")
            xbmc.sleep(500)

        if xbmc.getCondVisibility("Window.IsVisible(selectdialog)"):
            xbmc.log("EmbyCon.Screensaver selectdialog is visible")
        else:
            xbmc.log("EmbyCon.Screensaver selectdialog did not show")

        self.close()


if __name__ == '__main__':
    xbmc.log('EmbyCon.Screensaver Started')
    screensaver_gui = Screensaver('screen_saver.xml', __path__, 'default')
    screensaver_gui.doModal()
    xbmc.log('EmbyCon.Screensaver Exited')
    del screensaver_gui
    sys.modules.clear()
