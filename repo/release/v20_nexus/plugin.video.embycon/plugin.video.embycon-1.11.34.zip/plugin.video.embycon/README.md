# EmbyCon

EmbyCon is a lightweight [Kodi] addon that lets you browse and play media files from your [Emby] server directly within the Kodi interface.

## License

EmbyCon is licensed under the terms of the [GPLv2](LICENSE.txt).
